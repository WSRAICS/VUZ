﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Odbc;
using System.Data.SqlClient;

namespace Module1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            UpKey.Enabled = false;
            DownKey.Enabled = false;
            LeftKey.Enabled = false;
            RightKey.Enabled = false;
            Car1.Location = new Point(160, 850);
        }

        public int Num_Run = 0;
        public int Count_Swap = 0;

        private void PsevdoNeuron()
        {
            
            if (Car1.Image == Image.FromFile("C:/Users/kochn/Documents/МужВУЗ АИС/Module1/Module1/Image/WcarTop.png"))
            {
                if (Car1.Location.Y != 760 & Car1.Location.X != 160 | Car1.Location.Y != 760 & Car1.Location.X != 720 |
                    Car1.Location.Y != 560 & Car1.Location.X != 430 | Car1.Location.Y != 560 & Car1.Location.X != 160 |
                    Car1.Location.Y != 330 & Car1.Location.X != 160 | Car1.Location.Y != 330 & Car1.Location.X != 720 |
                    Car1.Location.Y != 430 & Car1.Location.X != 140 | Car1.Location.Y != 990 & Car1.Location.X != 140)
                {
                    Car1.Location = new Point(Car1.Location.X + 0, Car1.Location.Y - 10);
                }
            }
            if (Car1.Image == Image.FromFile("C:/Users/kochn/Documents/МужВУЗ АИС/Module1/Module1/Image/WcarBottom.png"))
            {
                if (Car1.Location.X != 720 & Car1.Location.Y != 560 | Car1.Location.X != 430 & Car1.Location.Y != 760 |
                    Car1.Location.X != 720 & Car1.Location.Y != 760 | Car1.Location.X != 160 & Car1.Location.Y != 760 |
                    Car1.Location.X != 160 & Car1.Location.Y != 560 | Car1.Location.X != 990 & Car1.Location.Y != 560 |
                    Car1.Location.X != 720 & Car1.Location.Y != 560 | Car1.Location.X != 720 & Car1.Location.Y != 140 |
                    Car1.Location.X != 430 & Car1.Location.Y != 330 | Car1.Location.X != 430 & Car1.Location.Y != 760 |
                    Car1.Location.X != 160 & Car1.Location.Y != 330 
                    )
                {
                    Car1.Location = new Point(Car1.Location.X + 0, Car1.Location.Y + 10);
                }
            }
            if (Car1.Image == Image.FromFile("C:/Users/kochn/Documents/МужВУЗ АИС/Module1/Module1/Image/WcarLeft.png"))
            {
                if (Car1.Location.X != 160 & Car1.Location.Y != 760 | Car1.Location.X != 160 & Car1.Location.Y != 560 |
                    Car1.Location.X != 160 & Car1.Location.Y != 330 | Car1.Location.X != 990 & Car1.Location.Y != 330 |
                    Car1.Location.X != 430 & Car1.Location.Y != 140)
                {
                    Car1.Location = new Point(Car1.Location.X - 10, Car1.Location.Y + 0);
                }
            }
            if (Car1.Image == Image.FromFile("C:/Users/kochn/Documents/МужВУЗ АИС/Module1/Module1/Image/WcarRight.png"))
            {
                if (Car1.Location.X != 720 & Car1.Location.Y != 760 | Car1.Location.X != 990 & Car1.Location.Y != 560 |
                    Car1.Location.X != 990 & Car1.Location.Y != 330 | Car1.Location.X != 990 & Car1.Location.Y != 140 |
                    Car1.Location.X != 720 & Car1.Location.Y != 330)
                {
                    Car1.Location = new Point(Car1.Location.X + 10, Car1.Location.Y + 0);
                }
            }

        }

        private void button1_Click(object sender, EventArgs e)
        {
            while (Car1.Location.Y != 770)
            {
                Car1.Location = new Point(Car1.Location.X + 0, Car1.Location.Y - 10);
            }
            this.PsevdoNeuron();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Car1.Location = new Point(160, 850);
        }

        private void button3_Click(object sender, EventArgs e)
        {

        }

        private void Tests_Running_Click(object sender, EventArgs e)
        {
            UpKey.Enabled = true;
            DownKey.Enabled = true;
            LeftKey.Enabled = true;
            RightKey.Enabled = true;
            timer1.Start();
        }

        private void UpKey_Click(object sender, EventArgs e)
        {
            Car1.Location = new Point(Car1.Location.X + 0, Car1.Location.Y - 10);
            Car1.Image = Image.FromFile("C:/Users/kochn/Documents/МужВУЗ АИС/Module1/Module1/Image/WcarTop.png");
        }

        private void DownKey_Click(object sender, EventArgs e)
        {
            Car1.Location = new Point(Car1.Location.X + 0, Car1.Location.Y + 10);
            Car1.Image = Image.FromFile("C:/Users/kochn/Documents/МужВУЗ АИС/Module1/Module1/Image/WcarBottom.png");
        }

        private void LeftKey_Click(object sender, EventArgs e)
        {
            Car1.Location = new Point(Car1.Location.X - 10, Car1.Location.Y + 0);
            Car1.Image = Image.FromFile("C:/Users/kochn/Documents/МужВУЗ АИС/Module1/Module1/Image/WcarLeft.png");
        }

        private void RightKey_Click(object sender, EventArgs e)
        {
            Car1.Location = new Point(Car1.Location.X + 10, Car1.Location.Y + 0);
            Car1.Image = Image.FromFile("C:/Users/kochn/Documents/МужВУЗ АИС/Module1/Module1/Image/WcarRight.png");
        }

        private void Conn()
        {
            string connection = @"Server = BORIS_MOBILE\MYSQLSERVER; Database=Module2DB; Trusted_Connection = True";
            SqlConnection Connect = new SqlConnection(connection);
            try
            {
                Connect.Open();
                textBox1.Text = "Подключение открыто";
                string SqlInput = "INSERT INTO Records (Num_Run, Count_Swap) VALUE (1, 15)";
                string SqlOutput = "SELECT * FROM Records";
                SqlCommand command1 = new SqlCommand(SqlInput, Connect);
                SqlCommand command2 = new SqlCommand(SqlOutput, Connect);
                SqlDataReader ReadTable = command2.ExecuteReader();
                if (ReadTable.HasRows)
                {
                    while (ReadTable.Read())
                    {
                        textBox2.Text = ReadTable.GetString(0); ReadTable.GetString(2);
                    }
                }
                else
                {
                    textBox2.Text = "No rows///";
                }
                ReadTable.Close();
            }
            catch (SqlException ex)
            {
                textBox1.Text = ex.Message;
            }
        }

        private void Test_Conn_Click(object sender, EventArgs e)
        {
            this.Conn();
        }

    }
}
