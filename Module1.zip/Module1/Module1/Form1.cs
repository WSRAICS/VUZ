﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Module1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            UpKey.Enabled = false;
            DownKey.Enabled = false;
            LeftKey.Enabled = false;
            RightKey.Enabled = false;
            Car1.Location = new Point(180, 630);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            while (Car1.Location.Y != 720)
            {
                Car1.Location = new Point(Car1.Location.X + 0, Car1.Location.Y - 10);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Car1.Location = new Point(180, 630);
        }

        private void button3_Click(object sender, EventArgs e)
        {

        }

        private void Tests_Running_Click(object sender, EventArgs e)
        {
            UpKey.Enabled = true;
            DownKey.Enabled = true;
            LeftKey.Enabled = true;
            RightKey.Enabled = true;
        }

        private void UpKey_Click(object sender, EventArgs e)
        {
            Car1.Location = new Point(Car1.Location.X + 0, Car1.Location.Y - 10);
            Car1.Image = Image.FromFile("C:/Users/kochn/Documents/МужВУЗ АИС/Module1/Module1/Image/WcarTop.png");
        }

        private void DownKey_Click(object sender, EventArgs e)
        {
            Car1.Location = new Point(Car1.Location.X + 0, Car1.Location.Y + 10);
            Car1.Image = Image.FromFile("C:/Users/kochn/Documents/МужВУЗ АИС/Module1/Module1/Image/WcarBottom.png");
        }

        private void LeftKey_Click(object sender, EventArgs e)
        {
            Car1.Location = new Point(Car1.Location.X - 10, Car1.Location.Y + 0);
            Car1.Image = Image.FromFile("C:/Users/kochn/Documents/МужВУЗ АИС/Module1/Module1/Image/WcarLeft.png");
        }

        private void RightKey_Click(object sender, EventArgs e)
        {
            Car1.Location = new Point(Car1.Location.X + 10, Car1.Location.Y + 0);
            Car1.Image = Image.FromFile("C:/Users/kochn/Documents/МужВУЗ АИС/Module1/Module1/Image/WcarRight.png");
        }
    }
}
